import Link from 'next/link';
import { PublicNav } from './components/PublicNav';

export default function HomePage() {
  return (
    <div>
      {/* HERO — gradient stands in for a real campus photo (see note in
          ARCHITECTURE.md on why: no image-generation tool available, and
          a random web photo can't be embedded without a license). Swap by
          replacing this div's background with an <Image src="/hero.jpg" />
          once a licensed/owned photo exists. */}
      <div className="relative overflow-hidden">
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(135deg, rgb(20 24 38) 0%, rgb(40 34 30) 45%, rgb(120 84 40) 75%, rgb(196 148 64) 100%)',
          }}
        />
        <div className="absolute inset-0 bg-ink/40" />

        <div className="relative">
          <PublicNav />

          <section className="px-8 pt-16 pb-24 max-w-6xl mx-auto relative">
            <p className="text-xs tracking-[0.2em] text-gold-bright mb-4 uppercase">
              The university student platform
            </p>
            <h1 className="text-6xl leading-[1.05] text-bone mb-6 max-w-2xl">
              Your Campus.
              <br />
              <span className="text-gold-bright">All in One Place.</span>
            </h1>
            <p className="text-bone/80 text-lg mb-8 max-w-lg">
              CampusOS is your all-in-one university companion — get the right
              information, find opportunities, connect with your community, and
              make the most of your university experience.
            </p>
            <div className="flex gap-4 mb-16">
              <Link href="/auth/register" className="bg-gold text-ink px-6 py-3 rounded-sm font-medium hover:bg-gold-bright transition-colors">
                Get Started
              </Link>
              <Link href="/features" className="border border-bone/30 text-bone px-6 py-3 rounded-sm hover:border-gold transition-colors">
                Explore Features
              </Link>
            </div>

            {/* Floating verification card — deliberately generic, no
                university named, since this is public/pre-selection. */}
            <div className="absolute top-8 right-8 hidden lg:block bg-ink/90 border border-border rounded-md p-5 w-72 backdrop-blur">
              <p className="text-bone text-sm mb-1">Are you a student?</p>
              <p className="text-muted text-xs mb-4">
                Get verified and unlock your personalized CampusOS experience.
              </p>
              <Link
                href="/auth/register"
                className="block text-center bg-gold text-ink text-sm py-2 rounded-sm font-medium hover:bg-gold-bright transition-colors"
              >
                Verify Student Identity →
              </Link>
            </div>

            {/* Quick-link icon row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-8 border-t border-bone/10">
              <QuickIcon icon={<AcademicsIcon />} title="Academic Support" subtitle="Courses, resources, quizzes" />
              <QuickIcon icon={<OpportunitiesIcon />} title="Opportunities" subtitle="Scholarships, jobs, internships" />
              <QuickIcon icon={<CampusIcon />} title="Campus Life" subtitle="Maps, services, events" />
              <QuickIcon icon={<CommunityIcon />} title="Community" subtitle="Connect, discuss, collaborate" />
            </div>
          </section>
        </div>
      </div>

      {/* WHY CAMPUSOS — 6-card feature grid */}
      <section className="px-8 py-20 border-t border-border">
        <div className="max-w-5xl mx-auto text-center mb-14">
          <p className="text-gold text-xs tracking-[0.2em] uppercase mb-3">Why CampusOS?</p>
          <h2 className="text-3xl text-bone mb-4">Everything You Need for University Life</h2>
          <p className="text-muted max-w-xl mx-auto">
            From academic support to campus services, CampusOS brings together
            all the essential tools and information you need in one powerful platform.
          </p>
        </div>
        <div className="max-w-5xl mx-auto grid md:grid-cols-3 gap-4">
          <FeatureCard icon={<AcademicsIcon />} title="Academic Excellence" body="Access course information, study resources, quizzes and track your progress." />
          <FeatureCard icon={<OpportunitiesIcon />} title="Opportunities" body="Find scholarships, internships, jobs and other opportunities tailored for you." />
          <FeatureCard icon={<CommunityIcon />} title="Vibrant Community" body="Join discussions, find study groups, connect with fellow students." />
          <FeatureCard icon={<CampusIcon />} title="Campus Experience" body="Explore the campus map, find services, locate facilities and stay informed." />
          <FeatureCard icon={<ProjectsIcon />} title="Student Projects" body="Discover, collaborate and showcase amazing student projects." />
          <FeatureCard icon={<BellIcon />} title="Stay Updated" body="Get the latest news, announcements, and important deadlines." />
        </div>
      </section>

      {/* HOW IT WORKS — deliberately a fixed light band for visual rhythm,
          independent of the dark/light theme toggle (a permanent design
          accent, not a mode). */}
      <section className="px-8 py-20" style={{ background: '#F2EFE9' }}>
        <div className="max-w-5xl mx-auto text-center mb-14">
          <p className="text-xs tracking-[0.2em] uppercase mb-3" style={{ color: '#B08020' }}>
            Get started in 3 simple steps
          </p>
          <h2 className="text-3xl mb-4" style={{ color: '#141210' }}>How CampusOS Works</h2>
          <p className="max-w-xl mx-auto" style={{ color: '#6B6355' }}>
            Getting started is quick and easy. In just a few steps, you'll have
            access to a personalized university experience.
          </p>
        </div>
        <div className="max-w-4xl mx-auto grid md:grid-cols-3 gap-10">
          <HowStep n="1" title="Create Your Account" body="Sign up with your details and choose your university." />
          <HowStep n="2" title="Verify Your Identity" body="Use your university email or student ID to get verified." />
          <HowStep n="3" title="Explore CampusOS" body="Get personalized content, access useful tools, and start making the most of your university life." />
        </div>
      </section>

      {/* LATEST UPDATES */}
      <section className="px-8 py-20 border-t border-border">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-gold text-xs tracking-[0.2em] uppercase mb-3">Latest updates</p>
              <h2 className="text-3xl text-bone">What's Happening on CampusOS</h2>
            </div>
            <Link href="/discover" className="text-gold text-sm hover:text-gold-bright whitespace-nowrap">
              View all updates →
            </Link>
          </div>
          <div className="grid md:grid-cols-4 gap-4">
            <UpdateCard tag="Announcement" tagColor="#C99A3E" title="OAU Academic Calendar for 2025/2026 Released" date="12 Sept 2025" />
            <UpdateCard tag="Scholarship" tagColor="#3E8A5C" title="Google Africa Developer Scholarship 2025" date="10 Sept 2025" />
            <UpdateCard tag="Event" tagColor="#7A4FC9" title="Tech & Innovation Summit (OAU)" date="8 Sept 2025" />
            <UpdateCard tag="Opportunity" tagColor="#3E7AC9" title="Internship Opportunity at Access Bank" date="5 Sept 2025" />
          </div>
        </div>
      </section>

      <footer className="px-8 py-12 border-t border-border">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between gap-8 mb-10">
            <div>
              <p className="font-display text-lg text-bone mb-1">CampusOS</p>
              <p className="text-muted text-sm">Your Campus. All in One Place.</p>
            </div>
            <div className="flex gap-10 text-sm">
              <Link href="/" className="text-muted hover:text-bone">Home</Link>
              <Link href="/features" className="text-muted hover:text-bone">Features</Link>
              <Link href="/about" className="text-muted hover:text-bone">About</Link>
              <Link href="/contact" className="text-muted hover:text-bone">Contact</Link>
            </div>
            <div className="flex gap-4">
              <SocialIcon><XIcon /></SocialIcon>
              <SocialIcon><InstagramIcon /></SocialIcon>
              <SocialIcon><YoutubeIcon /></SocialIcon>
              <SocialIcon><LinkedinIcon /></SocialIcon>
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between gap-2 pt-6 border-t border-border text-xs text-muted">
            <span>© {new Date().getFullYear()} CampusOS. All rights reserved.</span>
            <div className="flex gap-6">
              <Link href="/privacy" className="hover:text-bone">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-bone">Terms of Service</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function QuickIcon({ icon, title, subtitle }: { icon: React.ReactNode; title: string; subtitle: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-9 h-9 rounded-md bg-gold/15 border border-gold/30 flex items-center justify-center text-gold-bright shrink-0">
        {icon}
      </div>
      <div>
        <p className="text-bone text-sm">{title}</p>
        <p className="text-bone/50 text-xs">{subtitle}</p>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <div className="group bg-surface border border-border rounded-md p-6 hover:border-gold/40 transition-colors">
      <div className="w-10 h-10 rounded-md bg-gold/10 border border-gold/20 flex items-center justify-center text-gold mb-4">
        {icon}
      </div>
      <h3 className="text-bone mb-1.5">{title}</h3>
      <p className="text-muted text-sm leading-relaxed">{body}</p>
    </div>
  );
}

function HowStep({ n, title, body }: { n: string; title: string; body: string }) {
  return (
    <div className="text-center">
      <div
        className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium mx-auto mb-4"
        style={{ background: '#B08020', color: '#fff' }}
      >
        {n}
      </div>
      <h3 className="mb-2" style={{ color: '#141210' }}>{title}</h3>
      <p className="text-sm leading-relaxed" style={{ color: '#6B6355' }}>{body}</p>
    </div>
  );
}

function UpdateCard({ tag, tagColor, title, date }: { tag: string; tagColor: string; title: string; date: string }) {
  return (
    <div className="bg-surface border border-border rounded-md overflow-hidden hover:border-gold/40 transition-colors">
      <div className="h-24" style={{ background: `linear-gradient(135deg, ${tagColor}55, ${tagColor}22)` }}>
        <span
          className="inline-block text-[10px] uppercase tracking-wide text-white px-2 py-1 m-3 rounded-sm"
          style={{ background: tagColor }}
        >
          {tag}
        </span>
      </div>
      <div className="p-4">
        <p className="text-bone text-sm mb-3 leading-snug">{title}</p>
        <p className="text-muted text-xs">{date}</p>
      </div>
    </div>
  );
}

function SocialIcon({ children }: { children: React.ReactNode }) {
  return (
    <a href="#" className="w-8 h-8 rounded-full border border-border flex items-center justify-center text-muted hover:text-gold hover:border-gold/40 transition-colors">
      {children}
    </a>
  );
}

function AcademicsIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M12 3 2 8l10 5 10-5-10-5Z" />
      <path d="M6 10.5V16c0 1.5 2.5 3 6 3s6-1.5 6-3v-5.5" />
    </svg>
  );
}
function OpportunitiesIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="3" y="7" width="18" height="13" rx="1.5" />
      <path d="M8 7V5.5A1.5 1.5 0 0 1 9.5 4h5A1.5 1.5 0 0 1 16 5.5V7" />
    </svg>
  );
}
function CommunityIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="9" cy="8" r="3" />
      <path d="M2 20c0-3.3 3.1-6 7-6s7 2.7 7 6" />
      <circle cx="17" cy="8" r="2.3" opacity="0.6" />
      <path d="M16 14.2c2.9.5 5 2.6 5 5.8" opacity="0.6" />
    </svg>
  );
}
function CampusIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M3 21h18M5 21V9l7-5 7 5v12M9 21v-6h6v6" />
    </svg>
  );
}
function ProjectsIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.5.4.8 1 .8 1.6h5.4c0-.6.3-1.2.8-1.6A6 6 0 0 0 12 3Z" />
    </svg>
  );
}
function BellIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
      <path d="M13.7 21a2 2 0 0 1-3.4 0" />
    </svg>
  );
}
function XIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.9 2H22l-7.6 8.7L23.3 22h-7l-5.5-7.2L4.5 22H1.4l8.1-9.3L1 2h7.2l5 6.6L18.9 2Z" />
    </svg>
  );
}
function InstagramIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}
function YoutubeIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="2" y="5" width="20" height="14" rx="4" />
      <path d="M10 9v6l5-3-5-3Z" fill="currentColor" stroke="none" />
    </svg>
  );
}
function LinkedinIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M7 10v7M7 7v.01M11 17v-4.5a2.5 2.5 0 0 1 5 0V17" />
    </svg>
  );
}
