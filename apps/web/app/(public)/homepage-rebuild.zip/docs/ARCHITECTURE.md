# CampusOS — Architecture Decisions

This is the source of truth for architectural decisions. If a future change
contradicts something here, update this doc and explain why (per the brief's
final rule: "before making major architectural changes, explain the change
and why it is necessary").

## Stack

- **Language:** TypeScript everywhere (web, mobile, backend) — one shared
  types/logic package (`@campusos/shared`) prevents drift between layers,
  which matters most for the RBAC model below.
- **Web:** Next.js (App Router) — serves both the public marketing site and
  the authenticated app from one deployable.
- **Mobile:** React Native (Expo), sharing `@campusos/shared` with web.
- **Database:** PostgreSQL, single instance, `tenant_id`/`university_id` on
  every tenant-scoped row.
- **Cache/queue:** Redis — auth-context caching now; notification fan-out
  and search-index sync queues later.

## Deployment shape

Modular monolith, not microservices. One deployable, logically separated
modules (academics, opportunities, community, campus, messaging,
notifications). Given a small team, this gets separation of concerns
without the operational cost of running several services. Split out a
module (most likely search or notifications) only when load actually
demands it.

## Multi-tenancy

Every row that isn't global reference data carries `university_id`.
Enforce isolation at the data layer (Postgres RLS), not just in
application code — a bug in one module must not be able to leak another
university's data.

## Org graph (University → Faculty → Department → Programme → Level → Course)

Modeled as a **DAG**, not a strict tree: a user belongs to multiple nodes
simultaneously (faculty + department + level + several course groups), and
memberships change per term.

- `org_nodes`: the graph itself (id, parent_id, type, university_id).
- `user_org_memberships`: which nodes a user belongs to, with a
  `relationship` (enrolled/staff/advisee/rep) and optional `term`.
- `org_closure`: a **precomputed closure table** (ancestor_id,
  descendant_id, depth) for O(1) "is X under Y" queries.

**Decision: closure table over recursive CTE.** Org structure changes
rarely (a few times per semester); permission checks happen on nearly
every request. Pay the traversal cost once at write time (updating the
closure table when a node moves) rather than on every read.

## RBAC

Five roles: `student`, `rep`, `lecturer`, `adviser`, `admin`. Roles attach
to a **scope org_node** (nullable = tenant-wide), not globally — this
avoids a role-type explosion (no "CS Lecturer" vs "Physics Lecturer" as
distinct types).

**Permission resolution** (`can(userId, action, resourceOrgNodeId)`):
does the user have a role, at the target node or an ancestor of it, whose
role_type grants that action? Implemented as a single indexed join against
`org_closure` — see `packages/shared/src/auth.ts`. This is the one
function every middleware layer and API handler calls; never re-derive
permission logic ad hoc in a route handler.

Role-specific dashboards (Admin/Adviser/Lecturer/Rep) are **composed
views** over the same modules and the same `can()` checks — not separate
backend services or duplicated business logic.

Adviser is deliberately **observe-and-report only**: no role_type grants
it any write-permitting action in `ROLES_GRANTING`. It can read, and it
can write reports, but nothing else.

## Authentication vs. authorization

**Decision: JWT carries identity only. Roles/permissions are resolved
server-side per request, via a Redis-cached auth context, with explicit
invalidation on write.**

Rejected alternative: embedding roles as JWT claims. That's faster (no
per-request lookup) but incorrect by construction — a suspended user or a
revoked role stays valid until the token expires. Since suspension and
role changes are real Admin actions in this product, correctness wins.
The cost of the chosen approach is one Redis lookup per request plus an
explicit cache-invalidation call wherever roles/status are written
(`invalidateAuthContext`) — cheap relative to the guarantee it buys.

**Revised split (middleware vs. page-level):** originally all of this ran
in `middleware.ts`. In practice, Next.js's Node.js middleware runtime
(needed because `pg`/`ioredis` don't work in the default Edge runtime)
proved unreliable with `ioredis` in this environment even when explicitly
configured. Rather than depend on that framework feature, the check is
now split by what each layer can safely do:

- **`middleware.ts`** — Edge-safe only. Verifies the JWT signature (via
  `jose`, which works in Edge) and confirms a session exists. No database
  access. Sets `x-user-id` for downstream layers.
- **`lib/authz.ts`** (`requireRole`, `requireCan`) — called from a
  layout or page (Server Components, which always run in full Node.js
  regardless of middleware settings). Does the actual database-backed
  role/permission check via `loadAuthContext`/`can()`.

This is arguably a cleaner separation than the original design, not just
a workaround: middleware answers "is this a real session", pages answer
"is this session allowed to see this page". See `app/admin/layout.tsx`
for the worked pattern — every role-gated route (`/adviser`, `/lecturer`,
`/rep`) should follow the same shape.

## Route classification & middleware chain

Four route kinds (see brief §31):
- **Public** — no auth check.
- **Authenticated** — valid session required.
- **Scoped** — session + resource-level `can()` check (e.g. is this user
  enrolled in *this* course).
- **Role-gated** — session + a specific role_type required (`/admin/*`,
  `/adviser/*`, `/lecturer/*`, `/rep/*`).

Chain: authenticate (verify JWT) → load auth context (cached) → classify
route → authorize. Role-gating happens in `middleware.ts`; resource-level
scoped checks happen inside the specific route/API handler, since only the
handler knows the resource's org_node_id.

**403 vs 404:** a resource the user is authorized to know exists but can't
act on returns 403. A resource whose *existence* itself is sensitive
(e.g. a private course group's posts) returns 404 instead — 403 would
confirm it exists.

## Search (deferred build, decided direction)

Start with **Postgres full-text search** (`pg_trgm` + `to_tsvector`), not a
dedicated search service. At tens-of-thousands-of-users scale across many
tenants, per-tenant corpus size is well within what Postgres handles, and
it reuses existing RLS-based tenant/permission filtering instead of
building a second permission model. Isolate all search queries behind a
single `SearchService` interface so the implementation can be swapped for
a dedicated index (e.g. Typesense) later without touching call sites.

## Opportunities scope: Global vs. University-specific (two-tier, not three)

`opportunities.university_id` is nullable: `null` = Global (visible to every
university on the platform), set = visible only to that university.
Deliberately **no** intermediate "national" tier (e.g. "Nigeria-only") —
a scholarship that isn't tied to one specific university is just Global,
even if in practice it's only relevant to one country. This keeps the
filtering logic to a single boolean check instead of a
university/country/worldwide three-way match, at the acceptable cost of
occasionally showing a country-specific opportunity to students outside
that country. Revisit only if CampusOS actually expands to multiple
countries and this starts causing real confusion — not preemptively.

Schema supports group conversations from day one (`conversations` /
`conversation_participants` / `messages`, with `is_group`), but the MVP
**UI only exposes 1:1** — per the brief's "do not overbuild messaging in
the first version." This satisfies both "support future group chat" and
"don't overbuild now" without contradiction: the N=2 case of a group
schema is 1:1.

## Notifications fan-out

A triggering action (e.g. a Lecturer publishing a course announcement)
inserts one row into `notification_fanout_jobs` — fast, always succeeds.
A background worker (`processNextFanoutJob`) claims pending jobs with
`FOR UPDATE SKIP LOCKED` (safe for multiple worker instances), expands the
target audience via `org_closure` (so a Faculty-level notice reaches every
Department/Level/Course beneath it), and inserts `notifications` rows in
batches of 500. `cursor_user_id` on the job lets a crashed/restarted
worker resume from the last completed batch instead of re-notifying
everyone or silently dropping the rest. See `packages/shared/src/notifications.ts`.

## Academics workflow

`enrollments` tracks the academic-record lifecycle (registered → active →
completed/withdrawn) per term, distinct from `user_org_memberships` (which
just tracks community/permission membership in a course_group). A student
enrolling in a course creates both: an `enrollments` row (grade/status
tracking) and a `user_org_memberships` row (so they see the course's
community, resources, and get its notifications). `assignment_submissions`
tracks per-user submission state and grading, one row per (assignment, user).

**First vertical slice built** (`/academics`, `/academics/courses/[courseId]`):
data access lives in `lib/academics.ts` and is called **directly from
Server Components** — no API route layer for these reads. This is
deliberate: Next.js Server Components run in Node.js and can query
Postgres directly, so an API route would just be an unnecessary hop for
data that's only ever consumed by this app's own pages. API routes are
still the right tool for anything a client component needs to call after
the initial render (mutations, client-side interactivity), or anything a
future separate client (mobile app) needs — see the community post
DELETE route for that pattern. Course-level access control reuses
`user_org_memberships` (not `enrollments`) as the source of truth for
"can this user see this course," consistent with memberships being the
general community/resource access mechanism.

A `packages/db/seed.sql` script inserts one university, a full org
chain (faculty → department → programme → level → course_group), one
test user, and one course with a resource and an assignment, so this
slice can be verified against real data (`npm run db:seed`).

**Temporary dev-only auth bypass:** `app/api/dev/login-as-seed-user/route.ts`
issues a valid session cookie for the seeded user with no password check,
purely so protected pages can be tested before real login exists. It
self-disables in production (`NODE_ENV === 'production'`) but **must be
deleted once real login/register API routes are built** — it is not a
pattern to extend, just a temporary unblock.

**Second vertical slice built** (`/opportunities`, `/opportunities/[opportunityId]`):
this is the first route that must render differently for logged-out
visitors vs. logged-in users **on the same URL**, per the product
decision that Opportunities should be useful before signing in. This
required extracting the sidebar/topbar shell out of
`app/(app)/layout.tsx` into a plain component (`components/AppShell.tsx`),
since Next.js route-group layouts can't conditionally apply — a page
either sits inside a route group or it doesn't. The page itself calls
`getAuthContext()` (which returns `null` for logged-out visitors, not an
error) and wraps its content in `<AppShell>` or `<PublicNav>` accordingly.

Middleware also gained a third route category beyond
public/protected: **optional-auth** (`/opportunities`). These routes
never redirect to login; if a valid session cookie exists, middleware
attaches `x-user-id` so the page can personalize, but a missing or
invalid token just falls through as a logged-out view rather than
blocking access — the opposite failure mode from protected routes,
where a missing token blocks access.

Visibility rule for a single opportunity: Global (`university_id = null`)
is visible to anyone; university-specific is visible only to a logged-in
user whose `universityId` matches — otherwise `notFound()` (404, not 403),
consistent with the existing rule that a resource's existence itself
shouldn't be confirmable to someone without access to it.

## Design system: light/dark mode

Colors are defined as CSS variables (`--ink`, `--surface`, `--border`,
`--bone`, `--muted`, `--gold`, `--gold-bright`) in `globals.css`, and
`tailwind.config.ts` maps each Tailwind color name to its variable via
`rgb(var(--x) / <alpha-value>)`. This means every page already written —
Dashboard, Academics, Opportunities, the homepage — became theme-aware
with **zero markup changes**, since `bg-ink`/`text-bone`/etc. now resolve
differently depending on which theme is active, without any `dark:`
prefixed classes scattered through the codebase.

Dark is the default (`:root`); `[data-theme="light"]` on `<html>`
overrides every variable for light mode. `components/ThemeToggle.tsx`
flips the attribute and persists the choice to `localStorage`. A small
inline script in the root `<head>` (not a React effect — effects run
after first paint) reads that preference before hydration to avoid a
flash of the wrong theme on load.

## GPA/CGPA (reinstated)

Originally excluded from scope, then explicitly reinstated. Uses the
Nigerian 5-point grading scale (A=5 … F=0), not the 4.0 scale — this
matters because it changes what a given GPA number means, and OAU is the
reference university. Requires `courses.credit_units` (added to schema)
for weighting. `getGpaSummary()` in `lib/academics.ts` computes current-
term GPA and cumulative CGPA from `enrollments.grade`, excluding any
enrollment without a recorded grade (i.e., in-progress courses don't
affect either number, matching how GPA actually works academically).

## Homepage hero image (open, deliberately unresolved)

The homepage hero is designed to hold a real photograph, but no actual
image file is embedded — a CSS gradient stands in for it. This is
intentional, not an oversight: there is no image-generation tool
available in this build environment, and pulling a photo from a web
search into the app's codebase would mean embedding someone else's
copyrighted photograph in a commercial product without a license. To
finish this, either supply an owned/properly-licensed photo (e.g., a
photo of the actual campus, or a correctly-licensed stock photo) to be
wired in, or the gradient can stay as a permanent design choice.

## Fixed light "How it works" band

The homepage's "How CampusOS Works" section uses hardcoded light colors
(`#F2EFE9` background, `#141210` text) rather than the `ink`/`bone`
theme tokens. This is deliberate: it's a permanent visual-rhythm accent
present in both dark and light mode, not something that should invert
with the user's theme choice — matching the reference design, which
alternates dark/light bands regardless of a mode toggle.

## Not yet designed / open

- **Search ACL enforcement detail** — once search moves beyond a single
  university's Postgres FTS, cross-tenant query isolation needs explicit
  test coverage.
- **Real-time delivery for Messages** — schema supports conversations now;
  whether unread counts/typing indicators are polled or pushed (e.g. via
  WebSocket/SSE) isn't decided. Deferred since MVP messaging is 1:1 only.

## Explicitly out of scope for MVP (per brief §38)

Payments, marketplace (accommodation/transport), advanced AI features,
group messaging *UI* (schema only), cryptocurrency, CGPA calculator.
